<?php require_once('./partials/header.php'); ?>

<?php require_once('./partials/footer.php'); ?>