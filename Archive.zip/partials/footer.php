
<footer class="footer">tous droits etc. : FD-2024</footer>
<script src="./script.js"></script>
</body>
</html>